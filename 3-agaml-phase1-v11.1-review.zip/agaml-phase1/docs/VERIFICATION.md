# Revision 11 verification, 21 November 2026

Phase 1 design/foundation review only. Phase 1 is not complete.

Passed locally:
- 19 unit tests (16 policy/validation and 3 signup payload tests), covering pending/suspended users, owner-only review validation and customer/employee financial restrictions.
- Vite production build. Bundle-size warning remains.
- Owner, employee and customer dashboard preview visibility checks.
- Mobile sidebar open/close and no horizontal overflow at 320, 390 and 768 pixels.
- Disabled unconfigured login/signup, mode switching, customer/employee request radios and no runtime errors in smoke checks.
- Final desktop/mobile login, signup and dashboard screenshots inspected for layout, readable labels and role-specific content.

Revision 11.1 fixes the signup callable payload and adds regression coverage. Revision 11 adds a customer/employee account-type request in email and Google signup. It is not a role grant. Every new account remains pending with no operational permissions until owner approval. The client profile-creation race was removed so the requested account type reaches the registration callable first.

Design previews are development-only. All figures are unavailable rather than fake zero values. There is no claim of a working cloud connection. The supplied shop logo and owner-supplied generated bookstore artwork are used. The artwork is not a photograph of the real shop. The owner portrait remains a placeholder.

Owner navigation includes the requested service list, local navigation search, notification bell, not-yet-synced status and current-shift widget. Notification and close-shift controls stay disabled until real services exist. Employee and customer views exclude financial/admin content outside their scope. QR generation and camera scanning remain Phase 2 work.

Not verified/completed:
- Real Firebase account/project state or configuration.
- Live authentication, App Check, owner bootstrap or account-review UI.
- Firestore emulator/rules acceptance tests or callable integration tests.
- Suspension, cross-device state and customer ownership-query isolation against operational data.
- Stock, sales, invoices, accounting, orders, reports and backup workflows.
- Deployment.

The source follows the latest blueprint for implemented foundation files. Future modules are intentionally not supplied as empty stubs. Existing design concepts are labelled and must not be presented as finished operational modules.

This revision is packaged as a source ZIP for the review branch. Expanded repository source and Firebase setup are later steps. This checkpoint does not replace the main branch or change GitHub Pages settings.
