'use strict';

const pageTitles = {
  dashboard: 'لوحة التحكم', pos: 'الكاشير والمبيعات', invoices: 'الفواتير',
  orders: 'طلبات الطباعة', customers: 'العملاء والديون', inventory: 'المنتجات والمخزون',
  accounts: 'الحسابات والمصروفات', reports: 'التقارير'
};

const demoStoreKey = 'agmalHdayaV2Demo';
let activePage = 'dashboard';
let toastTimer;
let dashboardMarkup = '';

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function readDemoStore() {
  try {
    const raw = localStorage.getItem(demoStoreKey);
    return raw ? JSON.parse(raw) : { orders: [], customers: [] };
  } catch (error) {
    console.warn('تعذر قراءة بيانات التجربة من المتصفح:', error);
    return { orders: [], customers: [] };
  }
}

function saveDemoStore(data) {
  try {
    localStorage.setItem(demoStoreKey, JSON.stringify(data));
    return true;
  } catch (error) {
    console.error('تعذر حفظ بيانات التجربة:', error);
    showToast('تعذر الحفظ على هذا الجهاز. تحقق من مساحة المتصفح.');
    return false;
  }
}

function showToast(message) {
  const toast = $('#toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('show'), 2800);
}

function setPage(page) {
  if (!Object.hasOwn(pageTitles, page)) return;
  activePage = page;
  $$('.nav-link').forEach(button => {
    const selected = button.dataset.page === page;
    button.classList.toggle('active', selected);
    if (selected) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
  $('#currentSection').textContent = pageTitles[page];
  $('#sidebar').classList.remove('open');

  if (page === 'dashboard') {
    renderDashboard();
    return;
  }
  renderPlaceholder(page);
}

function renderPlaceholder(page) {
  const content = $('#pageContent');
  const icons = { pos: '▣', invoices: '▤', orders: '▧', customers: '♙', inventory: '▦', accounts: '◇', reports: '▥' };
  const descriptions = {
    pos: 'هنبني شاشة بيع واضحة مع حساب الإجمالي والمدفوع والمتبقي وربطها بالمخزون.',
    invoices: 'هنا هتظهر الفواتير المسجلة، تفاصيل كل فاتورة، والطباعة بعد توصيل قاعدة البيانات.',
    orders: 'هنضيف تسجيل طلبات الطباعة وتتبع حالتها من الاستلام حتى التسليم.',
    customers: 'هنضيف ملفات العملاء وكشوف الحساب والأرصدة والمدفوعات.',
    inventory: 'هنضيف المنتجات والكميات وحركة المخزون والتنبيهات.',
    accounts: 'هنضيف تسجيل المصروفات والإيرادات وحسابات العملاء.',
    reports: 'هنضيف تقارير المبيعات والمصروفات والأرباح بناءً على البيانات الفعلية.'
  };
  const action = page === 'orders' ? '<button class="primary-button" data-action="order">＋ إنشاء طلب تجريبي</button>' : '';
  content.innerHTML = `<div class="section-placeholder"><div class="placeholder-card"><div class="placeholder-icon">${icons[page] || '✦'}</div><h1>${pageTitles[page]}</h1><p>${descriptions[page] || 'هذا القسم سيُبنى في المرحلة المخصصة له.'}</p>${action}<p style="font-size:10px;margin:17px 0 0;color:#d8b56a">القسم غير مفعّل بعد — لن نعرض بيانات وهمية على أنها بيانات فعلية.</p></div></div><footer class="footer"><span>© ${new Date().getFullYear()} أجمل الهدايا</span><span>النسخة التأسيسية V2</span></footer>`;
  content.querySelectorAll('[data-action]').forEach(button => button.addEventListener('click', () => openEntryModal(button.dataset.action)));
}

function renderDashboard() {
  const content = $('#pageContent');
  if (!content.querySelector('.welcome-row')) {
    content.innerHTML = dashboardMarkup;
  }
  const data = readDemoStore();
  const savedOrders = Array.isArray(data.orders) ? data.orders : [];
  const savedCustomers = Array.isArray(data.customers) ? data.customers : [];
  const ordersValue = $('#ordersValue');
  const customersValue = $('#customersValue');
  if (ordersValue) ordersValue.innerHTML = `${String(8 + savedOrders.length).padStart(2, '0')} <small>طلبات</small>`;
  if (customersValue) customersValue.innerHTML = `${126 + savedCustomers.length} <small>عميل</small>`;
  const tbody = $('#ordersTableBody');
  if (!tbody) return;
  const examples = [
    { id: '#AG-1028', name: 'محمد أحمد', service: 'طباعة ملازم', status: 'قيد التنفيذ', className: 'status-progress', amount: 240, initial: 'م' },
    { id: '#AG-1027', name: 'سارة محمود', service: 'أبحاث وتنسيق', status: 'جاهز للتسليم', className: 'status-ready', amount: 85, initial: 'س' },
    { id: '#AG-1026', name: 'عمر خالد', service: 'تصوير مستندات', status: 'طلب جديد', className: 'status-new', amount: 35, initial: 'ع' },
    { id: '#AG-1025', name: 'ندى علي', service: 'تجليد وطباعة', status: 'تم التسليم', className: 'status-done', amount: 120, initial: 'ن' }
  ];
  const allRows = [...savedOrders.slice().reverse().map((order, index) => ({
    id: order.id || `#AG-NEW${String(index + 1).padStart(3, '0')}`,
    name: order.customer, service: order.service, status: 'طلب جديد', className: 'status-new', amount: Number(order.amount) || 0,
    initial: (order.customer || 'ع').trim().charAt(0) || 'ع'
  })), ...examples].slice(0, 8);
  tbody.innerHTML = allRows.map((order, index) => `<tr><td><span class="order-id">${escapeHtml(order.id)}</span></td><td><div class="customer-cell"><span class="customer-avatar ca${index % 4 + 1}">${escapeHtml(order.initial)}</span><span>${escapeHtml(order.name)}</span></div></td><td>${escapeHtml(order.service)}</td><td><span class="status ${order.className}">${escapeHtml(order.status)}</span></td><td class="amount">${formatMoney(order.amount)}</td></tr>`).join('');
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function formatMoney(value) {
  const amount = Number(value);
  return `${Number.isFinite(amount) ? amount.toLocaleString('en-US', { maximumFractionDigits: 2 }) : '0'} ج.م`;
}

function openEntryModal(type) {
  const form = $('#entryForm');
  const fields = $('#formFields');
  const title = $('#modalTitle');
  if (!form || !fields) return;
  form.dataset.entryType = type;
  if (type === 'customer') {
    title.textContent = 'إضافة عميل تجريبي';
    fields.innerHTML = `<label class="field-label">اسم العميل<input name="name" required maxlength="90" placeholder="اكتب اسم العميل"></label><label class="field-label">رقم الهاتف (اختياري)<input name="phone" inputmode="tel" maxlength="20" placeholder="01xxxxxxxxx"></label>`;
  } else {
    title.textContent = 'إنشاء طلب طباعة تجريبي';
    fields.innerHTML = `<label class="field-label">اسم العميل<input name="customer" required maxlength="90" placeholder="اسم العميل"></label><label class="field-label">نوع الخدمة<select name="service" required><option value="">اختر الخدمة</option><option>طباعة ملازم</option><option>تصوير مستندات</option><option>أبحاث وتنسيق</option><option>تجليد وطباعة</option><option>خدمة أخرى</option></select></label><label class="field-label">المبلغ بالجنيه المصري<input name="amount" required type="number" min="0" max="1000000" step="0.5" inputmode="decimal" placeholder="0.00"></label>`;
  }
  $('#modalBackdrop').hidden = false;
  const firstInput = fields.querySelector('input, select');
  if (firstInput) firstInput.focus();
}

function closeModal() {
  $('#modalBackdrop').hidden = true;
  $('#entryForm').reset();
}

function handleEntrySubmit(event) {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;
  const values = Object.fromEntries(new FormData(form).entries());
  const data = readDemoStore();
  if (form.dataset.entryType === 'customer') {
    data.customers = Array.isArray(data.customers) ? data.customers : [];
    data.customers.push({ ...values, createdAt: new Date().toISOString() });
  } else {
    const amount = Number(values.amount);
    if (!Number.isFinite(amount) || amount < 0) {
      showToast('من فضلك أدخل مبلغًا صحيحًا.');
      return;
    }
    data.orders = Array.isArray(data.orders) ? data.orders : [];
    data.orders.push({ ...values, amount, id: `#AG-NEW${String(data.orders.length + 1).padStart(3, '0')}`, createdAt: new Date().toISOString() });
  }
  if (!saveDemoStore(data)) return;
  closeModal();
  if (activePage !== 'dashboard') setPage('dashboard');
  else renderDashboard();
  showToast(form.dataset.entryType === 'customer' ? 'تم حفظ العميل تجريبيًا على هذا الجهاز.' : 'تم حفظ الطلب التجريبي على هذا الجهاز.');
}

function bindEvents() {
  document.addEventListener('click', event => {
    const pageButton = event.target.closest('[data-page]');
    if (pageButton) {
      event.preventDefault();
      setPage(pageButton.dataset.page);
      return;
    }
    const actionButton = event.target.closest('[data-action]');
    if (actionButton) openEntryModal(actionButton.dataset.action);
  });
  $('#menuToggle')?.addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  $('#closeModal')?.addEventListener('click', closeModal);
  $('#cancelModal')?.addEventListener('click', closeModal);
  $('#modalBackdrop')?.addEventListener('click', event => { if (event.target === $('#modalBackdrop')) closeModal(); });
  $('#entryForm')?.addEventListener('submit', handleEntrySubmit);
  document.addEventListener('click', event => {
    if (event.target.closest('#refreshButton')) { renderDashboard(); showToast('تم تحديث عرض البيانات التجريبية.'); }
    if (event.target.closest('#helpButton')) showToast('هذه نسخة واجهة تجريبية؛ لا تستخدمها لتسجيل معاملات مالية حقيقية بعد.');
  });
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && !$('#modalBackdrop').hidden) closeModal(); });
}

function initialize() {
  const now = new Date();
  $('#todayLabel').textContent = new Intl.DateTimeFormat('ar-EG', { weekday: 'short', day: 'numeric', month: 'short' }).format(now);
  $('#yearLabel').textContent = String(now.getFullYear());
  dashboardMarkup = $('#pageContent').innerHTML;
  bindEvents();
  renderDashboard();
  if (window.location.hash === '#dashboard') history.replaceState(null, '', window.location.pathname + window.location.search);
}

document.addEventListener('DOMContentLoaded', initialize);
